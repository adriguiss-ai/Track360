# TRACK360 — GitHub build

This package is arranged at repository root and is intended to be uploaded/extracted into a GitHub repository.

GitHub Actions workflow: `.github/workflows/build-apk.yml`.

The workflow installs Java 17 and Gradle 8.10.2, then builds `assembleDebug` and uploads `app-debug.apk` as the `TRACK360-debug-apk` artifact.
