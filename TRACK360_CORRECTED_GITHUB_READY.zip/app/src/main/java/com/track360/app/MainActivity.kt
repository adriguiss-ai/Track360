package com.track360.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

data class Charge(val id: Long, val year: Int, val month: Int, val type: String, val category: String, val description: String, val amount: Double, val date: String)

private val Bg = Color(0xFF080A0D)
private val Card = Color(0xFF14171C)
private val Blue = Color(0xFF158BFF)
private val Blue2 = Color(0xFF20B8FF)
private val Yellow = Color(0xFFFFC400)
private val White = Color(0xFFF4F6F8)
private val Muted = Color(0xFF9BA3AE)
private val Green = Color(0xFF35D07F)
private val Purple = Color(0xFFB66CFF)
private val months = listOf("Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre")

class Store(context: Context) {
    private val prefs = context.getSharedPreferences("track360", Context.MODE_PRIVATE)
    var charges by mutableStateOf(load())
        private set
    private fun load(): List<Charge> = runCatching { parse(JSONArray(prefs.getString("data", "[]") ?: "[]")) }.getOrDefault(emptyList())
    private fun persist() { prefs.edit().putString("data", toJson().toString()).apply() }
    private fun toJsonArray(): JSONArray = JSONArray().apply { charges.forEach { put(JSONObject().apply { put("id",it.id); put("year",it.year); put("month",it.month); put("type",it.type); put("category",it.category); put("description",it.description); put("amount",it.amount); put("date",it.date) }) } }
    fun toJson(): JSONObject = JSONObject().apply { put("app","Track360"); put("version",2); put("charges",toJsonArray()) }
    fun add(c: Charge) { charges = charges + c; persist() }
    fun delete(id: Long) { charges = charges.filterNot { it.id == id }; persist() }
    fun importJson(raw: String) { runCatching { val o=JSONObject(raw); val a=o.optJSONArray("charges") ?: JSONArray(); charges=parse(a); persist() } }
    private fun parse(a: JSONArray): List<Charge> = buildList { for (i in 0 until a.length()) { val o=a.getJSONObject(i); add(Charge(o.optLong("id",System.currentTimeMillis()+i),o.optInt("year",2026),o.optInt("month",1),o.optString("type","Normale"),o.optString("category",""),o.optString("description",""),o.optDouble("amount",0.0),o.optString("date",""))) } }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { Track360App() } }
}

@Composable
fun Track360App() {
    val context=androidx.compose.ui.platform.LocalContext.current
    val store=remember { Store(context) }
    var tab by remember { mutableIntStateOf(0) }
    var selectedYear by remember { mutableIntStateOf(Calendar.getInstance().get(Calendar.YEAR)) }
    var selectedMonth by remember { mutableIntStateOf(Calendar.getInstance().get(Calendar.MONTH)+1) }
    var snackbar by remember { mutableStateOf("") }
    val export=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri -> if(uri!=null){ context.contentResolver.openOutputStream(uri)?.use { it.write(store.toJson().toString(2).toByteArray()) }; snackbar="Sauvegarde JSON créée." } }
    val import=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if(uri!=null) { runCatching { context.contentResolver.openInputStream(uri)?.use { store.importJson(String(it.readBytes())) }; snackbar="Données restaurées." }.onFailure { snackbar="Fichier JSON invalide." } } }
    MaterialTheme(colorScheme=darkColorScheme(primary=Blue,secondary=Blue2,background=Bg,surface=Card,onBackground=White,onSurface=White)) {
        Scaffold(containerColor=Bg,bottomBar={ BottomBar(tab){tab=it} }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when(tab){
                    0->HomeScreen({tab=1},{tab=4})
                    1->AddScreen(store)
                    2->MonthlyScreen(store,selectedYear,selectedMonth,{selectedYear=it},{selectedMonth=it})
                    3->AnnualScreen(store,selectedYear,{selectedYear=it})
                    else->AllYearsScreen(store,{export.launch("TRACK360_backup.json")},{import.launch(arrayOf("application/json","text/plain","*/*"))})
                }
                if(snackbar.isNotBlank()){ LaunchedEffect(snackbar){ kotlinx.coroutines.delay(1800); snackbar="" }; Snackbar(Modifier.align(Alignment.BottomCenter).padding(16.dp)){Text(snackbar)} }
            }
        }
    }
}

@Composable fun BottomBar(selected:Int,onSelect:(Int)->Unit){ NavigationBar(containerColor=Color(0xFF0D1015)){ listOf("Accueil" to Icons.Default.Home,"Saisie" to Icons.Default.AddCircle,"Mensuelle" to Icons.Default.CalendarMonth,"Annuelle" to Icons.Default.BarChart,"Toutes" to Icons.Default.Storage).forEachIndexed{ i,p->NavigationBarItem(selected==i,{onSelect(i)},{Icon(p.second,null)},label={Text(p.first,fontSize=10.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=if(i==4)Yellow else Blue,selectedTextColor=White,indicatorColor=Color(0xFF142638))) } } }

@Composable fun Header(title:String,subtitle:String?=null){ Column(Modifier.fillMaxWidth().padding(20.dp)){Text(title,fontSize=27.sp,fontWeight=FontWeight.Bold);if(subtitle!=null)Text(subtitle,color=Muted,fontSize=13.sp)} }
@Composable fun Logo(){Row(Modifier.fillMaxWidth().padding(20.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(58.dp).background(Color(0xFF101B2A),RoundedCornerShape(18.dp)),contentAlignment=Alignment.Center){Text("T",color=Blue,fontSize=32.sp,fontWeight=FontWeight.Black);Text("360",color=Blue2,fontSize=10.sp,modifier=Modifier.padding(top=37.dp))};Spacer(Modifier.width(12.dp));Column{Text("TRACK360",fontSize=24.sp,fontWeight=FontWeight.Black);Text("TRACK SMARTER",color=Muted,fontSize=10.sp,letterSpacing=3.sp)}}}

@Composable fun HomeScreen(onAdd:()->Unit,onAll:()->Unit){LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Logo();Text("Suivez vos charges simplement.",color=Muted,modifier=Modifier.padding(horizontal=20.dp));Spacer(Modifier.height(8.dp))};item{ActionCard("Ajouter une charge","Normale ou ponctuelle",Icons.Default.AddCircle,Blue,onAdd)};item{ActionCard("Synthèse mensuelle","Normales, ponctuelles et graphique circulaire",Icons.Default.CalendarMonth,Blue2,{})};item{ActionCard("Synthèse annuelle","Totaux + évolution mensuelle en bâtons",Icons.Default.BarChart,Blue2,{})};item{ActionCard("Toutes les années","Vue globale des années enregistrées",Icons.Default.Storage,Blue2,onAll)};item{ActionCard("Sauvegarde et restauration","Exporter / importer JSON",Icons.Default.CloudSync,Yellow,onAll)}}}
@Composable fun ActionCard(title:String,sub:String,icon:androidx.compose.ui.graphics.vector.ImageVector,color:Color,onClick:()->Unit){Card(Modifier.fillMaxWidth().padding(horizontal=20.dp).clickable{onClick()},colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=color,modifier=Modifier.size(38.dp));Spacer(Modifier.width(14.dp));Column{Text(title,fontSize=18.sp,fontWeight=FontWeight.Bold);Text(sub,color=Muted,fontSize=12.sp)};Spacer(Modifier.weight(1f));Icon(Icons.Default.ChevronRight,null,tint=Muted)}}}

@Composable fun AddScreen(store:Store){var year by remember{mutableIntStateOf(Calendar.getInstance().get(Calendar.YEAR))};var month by remember{mutableIntStateOf(Calendar.getInstance().get(Calendar.MONTH)+1)};var type by remember{mutableStateOf("Normale")};var category by remember{mutableStateOf("Alimentation")};var description by remember{mutableStateOf("")};var amount by remember{mutableStateOf("")};var date by remember{mutableStateOf(SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(Date()))};var msg by remember{mutableStateOf("")};LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(8.dp)){item{Header("Ajouter une charge","Saisissez une charge normale ou ponctuelle")};item{Field("Année",year.toString()){year=it.toIntOrNull()?:year}};item{Text("Mois",color=Muted,modifier=Modifier.padding(horizontal=20.dp))};item{Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal=16.dp)){months.forEachIndexed{i,m->FilterChip(i+1==month,{month=i+1},{Text(m)},modifier=Modifier.padding(horizontal=3.dp))}}};item{Text("Type de charge",color=Muted,modifier=Modifier.padding(horizontal=20.dp))};item{Row(Modifier.padding(horizontal=20.dp)){FilterChip(type=="Normale",{type="Normale"},{Text("Normale")});Spacer(Modifier.width(10.dp));FilterChip(type=="Ponctuelle",{type="Ponctuelle"},{Text("Ponctuelle")},colors=FilterChipDefaults.filterChipColors(selectedContainerColor=Yellow.copy(alpha=.18f),selectedLabelColor=Yellow))}};item{Field("Catégorie",category){category=it}};item{Field("Description",description){description=it}};item{Field("Montant (DH)",amount){amount=it}};item{Field("Date",date){date=it}};item{Button({val v=amount.replace(',','.').toDoubleOrNull();if(v!=null&&v>0){store.add(Charge(System.currentTimeMillis(),year,month,type,category,description,v,date));description="";amount="";msg="Charge enregistrée ✓"}else msg="Montant invalide."},Modifier.fillMaxWidth().padding(20.dp),colors=ButtonDefaults.buttonColors(containerColor=Blue)){Text("Enregistrer",fontWeight=FontWeight.Bold)}};item{if(msg.isNotBlank())Text(msg,color=if(msg.contains("✓"))Green else Yellow,modifier=Modifier.padding(horizontal=20.dp))}}}
@Composable fun Field(label:String,value:String,onChange:(String)->Unit){OutlinedTextField(value,onChange,label={Text(label)},modifier=Modifier.fillMaxWidth().padding(horizontal=20.dp,vertical=4.dp))}

@Composable fun MonthlyScreen(store:Store,year:Int,month:Int,onYear:(Int)->Unit,onMonth:(Int)->Unit){val list=store.charges.filter{it.year==year&&it.month==month};val n=list.filter{it.type=="Normale"}.sumOf{it.amount};val p=list.filter{it.type=="Ponctuelle"}.sumOf{it.amount};LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(8.dp)){item{Header("Synthèse mensuelle","Sans évolution mensuelle — vue dédiée au mois")};item{SelectorYearMonth(year,month,onYear,onMonth)};item{StatCard("Charges normales",n,Blue)};item{StatCard("Charges ponctuelles",p,Yellow)};item{StatCard("Total du mois",n+p,Blue2)};item{Donut(n,p)};item{ChargeList(list,store)}}}
@Composable fun SelectorYearMonth(year:Int,month:Int,onYear:(Int)->Unit,onMonth:(Int)->Unit){Row(Modifier.padding(horizontal=20.dp),verticalAlignment=Alignment.CenterVertically){OutlinedButton({onYear(year-1)}){Text("−")};Text(" $year ",fontWeight=FontWeight.Bold);OutlinedButton({onYear(year+1)}){Text("+")};Spacer(Modifier.width(10.dp));OutlinedButton({onMonth(if(month==12)1 else month+1)}){Text(months[month-1])}}}

@Composable fun AnnualScreen(store:Store,year:Int,onYear:(Int)->Unit){val by=(1..12).map{m->store.charges.filter{it.year==year&&it.month==m}};val n=by.map{x->x.filter{it.type=="Normale"}.sumOf{it.amount}};val p=by.map{x->x.filter{it.type=="Ponctuelle"}.sumOf{it.amount}};val tn=n.sum();val tp=p.sum();LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(8.dp)){item{Header("Synthèse annuelle","Évolution mensuelle par mois")};item{Row(Modifier.padding(horizontal=20.dp),verticalAlignment=Alignment.CenterVertically){OutlinedButton({onYear(year-1)}){Text("−")};Text(" $year ",fontWeight=FontWeight.Bold);OutlinedButton({onYear(year+1)}){Text("+")}}};item{StatCard("Charges normales",tn,Blue)};item{StatCard("Charges ponctuelles",tp,Yellow)};item{StatCard("Total annuel",tn+tp,Blue2)};item{Donut(tn,tp)};item{Text("Évolution mensuelle",fontSize=20.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(20.dp,10.dp))};item{BarChart(n,p)};item{MonthlyTable(n,p)}}}
@Composable fun MonthlyTable(n:List<Double>,p:List<Double>){Card(Modifier.fillMaxWidth().padding(20.dp),colors=CardDefaults.cardColors(containerColor=Card)){Column(Modifier.padding(12.dp)){Row(Modifier.fillMaxWidth()){Text("Mois",Modifier.weight(1.4f),color=Muted);Text("Norm.",Modifier.weight(1f),color=Muted);Text("Ponct.",Modifier.weight(1f),color=Muted);Text("Total",Modifier.weight(1f),color=Muted)};(1..12).forEach{i->Row(Modifier.fillMaxWidth().padding(vertical=6.dp)){Text(months[i-1],Modifier.weight(1.4f));Text(money(n[i-1]),Modifier.weight(1f));Text(money(p[i-1]),Modifier.weight(1f),color=Yellow);Text(money(n[i-1]+p[i-1]),Modifier.weight(1f),fontWeight=FontWeight.SemiBold)}}}}}

@Composable fun Donut(a:Double,b:Double){val total=a+b;Card(Modifier.fillMaxWidth().padding(horizontal=20.dp),colors=CardDefaults.cardColors(containerColor=Card)){Column(Modifier.padding(18.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("Répartition",fontWeight=FontWeight.Bold);Canvas(Modifier.size(190.dp).padding(10.dp)){val sweep=if(total<=0)0f else 360f*(a/total).toFloat();drawArc(Blue,-90f,sweep,false,style=Stroke(34f,cap=StrokeCap.Butt));drawArc(Yellow,-90f+sweep,360f-sweep,false,style=Stroke(34f,cap=StrokeCap.Butt))};Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){Text("Normales ${money(a)} DH",color=Blue,fontSize=12.sp);Text("Ponctuelles ${money(b)} DH",color=Yellow,fontSize=12.sp)}}}}
@Composable fun BarChart(n:List<Double>,p:List<Double>){val max=(n.zip(p).maxOfOrNull{it.first+it.second}?:1.0).coerceAtLeast(1.0);Canvas(Modifier.fillMaxWidth().height(230.dp).padding(18.dp)){val bw=size.width/12f*.58f;n.forEachIndexed{i,v->val total=v+p[i];val x=i*(size.width/12f)+(size.width/12f-bw)/2f;val h=(total/max*(size.height-25f)).toFloat();drawRect(Blue,x,size.height-h-10f,x+bw,size.height-10f);if(total>0){val ph=(p[i]/total*h).toFloat();drawRect(Yellow,x,size.height-10f-ph,x+bw,size.height-10f)}}}}

@Composable fun AllYearsScreen(store:Store,onExport:()->Unit,onImport:()->Unit){val years=store.charges.map{it.year}.distinct().sortedDescending();LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(8.dp)){item{Header("Toutes les années","Vue globale des années enregistrées")};if(years.isEmpty())item{Text("Aucune année enregistrée.",color=Muted,modifier=Modifier.padding(20.dp))};items(years){y->val list=store.charges.filter{it.year==y};val n=list.filter{it.type=="Normale"}.sumOf{it.amount};val p=list.filter{it.type=="Ponctuelle"}.sumOf{it.amount};Card(Modifier.fillMaxWidth().padding(horizontal=20.dp),colors=CardDefaults.cardColors(containerColor=Card)){Column(Modifier.padding(18.dp)){Text(y.toString(),fontSize=20.sp,fontWeight=FontWeight.Bold);Text("Normales ${money(n)} DH",color=Blue2);Text("Ponctuelles ${money(p)} DH",color=Yellow);Text("Total ${money(n+p)} DH",fontWeight=FontWeight.Bold)}}};item{BackupCard(onExport,onImport)}}}
@Composable fun BackupCard(onExport:()->Unit,onImport:()->Unit){Card(Modifier.fillMaxWidth().padding(20.dp),colors=CardDefaults.cardColors(containerColor=Card)){Column(Modifier.padding(18.dp)){Text("Sauvegarde et restauration",fontSize=19.sp,fontWeight=FontWeight.Bold);Text("Exportez ou importez toutes vos données au format JSON.",color=Muted);Button(onExport,Modifier.fillMaxWidth().padding(top=12.dp),colors=ButtonDefaults.buttonColors(containerColor=Blue)){Icon(Icons.Default.FileDownload,null);Spacer(Modifier.width(8.dp));Text("Exporter en JSON")};OutlinedButton(onImport,Modifier.fillMaxWidth().padding(top=8.dp)){Icon(Icons.Default.FileUpload,null);Spacer(Modifier.width(8.dp));Text("Importer un fichier JSON")};Text("La restauration remplacera les données actuelles.",color=Yellow,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))}}}
@Composable fun StatCard(title:String,value:Double,color:Color){Card(Modifier.fillMaxWidth().padding(horizontal=20.dp),colors=CardDefaults.cardColors(containerColor=Card)){Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(8.dp).background(color,RoundedCornerShape(4.dp)));Spacer(Modifier.width(12.dp));Column{Text(title,color=Muted,fontSize=13.sp);Text("${money(value)} DH",fontSize=22.sp,fontWeight=FontWeight.Bold,color=if(color==Yellow)Yellow else White)}}}}
@Composable fun ChargeList(list:List<Charge>,store:Store){if(list.isEmpty()){itemSpacer();Text("Aucune charge pour ce mois.",color=Muted,modifier=Modifier.padding(20.dp));return};Text("Charges enregistrées",fontSize=19.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(20.dp));list.sortedByDescending{it.id}.forEach{c->Card(Modifier.fillMaxWidth().padding(horizontal=20.dp,vertical=3.dp),colors=CardDefaults.cardColors(containerColor=Card)){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(c.description.ifBlank{c.category},fontWeight=FontWeight.SemiBold);Text("${c.category} • ${c.type} • ${c.date}",fontSize=11.sp,color=if(c.type=="Ponctuelle")Yellow else Muted)};Text(money(c.amount),fontWeight=FontWeight.Bold);IconButton({store.delete(c.id)}){Icon(Icons.Default.DeleteOutline,null,tint=Muted)}}}}}
@Composable fun itemSpacer(){Spacer(Modifier.height(1.dp))}
fun money(v:Double)=NumberFormat.getNumberInstance(Locale.FRANCE).format(v)
