# TRACK360 — TRACK SMARTER

Version corrigée et prête pour GitHub Actions.

Fonctions :
- Charges mensuelles : Normale / Ponctuelle
- Année et mois Janvier à Décembre
- Catégorie, description, montant, date
- Synthèse mensuelle + graphique circulaire
- Synthèse annuelle Normales / Ponctuelles
- Évolution mensuelle annuelle en graphique à barres
- Vue de toutes les années enregistrées
- Sauvegarde et restauration JSON
- Interface Black avec bleu et jaune/ambre pour Ponctuelle

Le projet n'utilise plus Kotlin Serialization : le JSON est géré avec org.json pour éviter les erreurs de plugin rencontrées sur GitHub Actions.
