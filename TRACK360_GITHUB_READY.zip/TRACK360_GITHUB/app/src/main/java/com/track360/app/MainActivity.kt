package com.track360.app

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.text.NumberFormat
import java.util.Locale

private val Bg = Color(0xFF071018)
private val Card = Color(0xFF101C25)
private val Card2 = Color(0xFF152531)
private val Blue = Color(0xFF1597FF)
private val Yellow = Color(0xFFFFC107)
private val White = Color(0xFFF4F8FB)
private val Muted = Color(0xFFA9BAC6)
private val Green = Color(0xFF35D07F)

@Serializable
data class Charge(
    val id: Long,
    val year: Int,
    val month: Int,
    val type: String,
    val amount: Double,
    val description: String = ""
)

@Serializable
data class Backup(val charges: List<Charge>)

class Store(private val context: Context) {
    private val prefs = context.getSharedPreferences("track360", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true }
    fun load(): List<Charge> = runCatching {
        json.decodeFromString<Backup>(prefs.getString("data", "{\"charges\":[]}")!!).charges
    }.getOrDefault(emptyList())
    fun save(items: List<Charge>) {
        prefs.edit().putString("data", json.encodeToString(Backup(items))).apply()
    }
    fun export(items: List<Charge>, uri: Uri) {
        context.contentResolver.openOutputStream(uri)?.use {
            it.write(json.encodeToString(Backup(items)).toByteArray())
        }
    }
    fun import(uri: Uri): List<Charge> =
        context.contentResolver.openInputStream(uri)?.use {
            json.decodeFromString<Backup>(it.readBytes().toString(Charsets.UTF_8)).charges
        } ?: emptyList()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Track360App() }
    }
}

@Composable
fun Track360App() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val store = remember { Store(context) }
    var charges by remember { mutableStateOf(store.load()) }
    var tab by remember { mutableStateOf(0) }
    var year by remember { mutableStateOf(2026) }
    var month by remember { mutableStateOf(9) }
    var showAdd by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) {
        if (it != null) { store.export(charges, it); message = "Sauvegarde JSON créée." }
    }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) {
        if (it != null) runCatching {
            charges = store.import(it)
            store.save(charges)
            message = "Données restaurées."
        }.onFailure { message = "Fichier JSON invalide." }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Card, primary = Blue,
            onBackground = White, onSurface = White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = { BottomBar(tab) { tab = it } }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (tab) {
                    0 -> HomeScreen(onAdd = { showAdd = true }, onBackup = { tab = 4 })
                    1 -> AddScreen(
                        onSave = { c -> charges = charges + c; store.save(charges); message = "Charge enregistrée." },
                        onBack = { tab = 0 }
                    )
                    2 -> MonthlyScreen(charges, year, month) { y, m -> year = y; month = m }
                    3 -> AnnualScreen(charges, year) { year = it }
                    else -> BackupScreen(
                        onExport = { export.launch("track360_backup.json") },
                        onImport = { import.launch(arrayOf("application/json", "text/json")) }
                    )
                }
                if (showAdd) {
                    AddDialog(
                        onDismiss = { showAdd = false },
                        onSave = { c -> charges = charges + c; store.save(charges); showAdd = false; message = "Charge enregistrée." }
                    )
                }
                if (message.isNotBlank()) {
                    LaunchedEffect(message) {
                        kotlinx.coroutines.delay(1800)
                        message = ""
                    }
                    Snackbar(
                        Modifier.align(Alignment.BottomCenter).padding(16.dp),
                        containerColor = Card2
                    ) { Text(message) }
                }
            }
        }
    }
}

@Composable
fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xFF09141D)) {
        listOf(
            "Accueil" to Icons.Default.Home,
            "Saisie" to Icons.Default.AddCircle,
            "Mensuelle" to Icons.Default.CalendarMonth,
            "Annuelle" to Icons.Default.BarChart,
            "JSON" to Icons.Default.Storage
        ).forEachIndexed { i, pair ->
            NavigationBarItem(
                selected = selected == i,
                onClick = { onSelect(i) },
                icon = { Icon(pair.second, null) },
                label = { Text(pair.first, fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = if (i == 4) Yellow else Blue,
                    selectedTextColor = White,
                    indicatorColor = Color(0xFF122C3D)
                )
            )
        }
    }
}

@Composable
fun HomeScreen(onAdd: () -> Unit, onBackup: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(Modifier.height(12.dp))
            Text("TRACK", color = White, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("360", color = Blue, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
            }
            Text("TRACK SMARTER", color = Muted, letterSpacing = 4.sp, fontSize = 12.sp)
        }
        item { ActionCard("Ajouter une charge", "Saisir une nouvelle dépense", Icons.Default.AddCircle, Blue, onAdd) }
        item { ActionCard("Synthèse mensuelle", "Normales, ponctuelles et camembert", Icons.Default.CalendarMonth, Blue) {} }
        item { ActionCard("Vue annuelle", "Tableau + évolution mensuelle", Icons.Default.BarChart, Blue) {} }
        item { ActionCard("Sauvegarde / restauration", "Exporter ou importer en JSON", Icons.Default.Storage, Yellow, onBackup) }
    }
}

@Composable
fun ActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Card),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = color, modifier = Modifier.size(42.dp))
            Spacer(Modifier.width(16.dp))
            Column { Text(title, fontSize = 19.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted) }
        }
    }
}

@Composable
fun AddScreen(onSave: (Charge) -> Unit, onBack: () -> Unit) {
    AddForm(onSave, onBack)
}

@Composable
fun AddForm(onSave: (Charge) -> Unit, onBack: () -> Unit) {
    var year by remember { mutableStateOf(2026) }
    var month by remember { mutableStateOf(9) }
    var type by remember { mutableStateOf("Normale") }
    var amount by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Ajouter une charge", fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        item { OutlinedTextField(year.toString(), { year = it.filter(Char::isDigit).toIntOrNull() ?: 2026 }, label={Text("Année")}, modifier=Modifier.fillMaxWidth()) }
        item { OutlinedTextField(monthName(month), { }, label={Text("Mois")}, modifier=Modifier.fillMaxWidth(), readOnly=true) }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                FilterChip(selected=type=="Normale", onClick={type="Normale"}, label={Text("Normale")}, leadingIcon={Icon(Icons.Default.AccountBalanceWallet,null)})
                FilterChip(selected=type=="Ponctuelle", onClick={type="Ponctuelle"}, label={Text("Ponctuelle")}, leadingIcon={Icon(Icons.Default.CalendarMonth,null)})
            }
        }
        item { OutlinedTextField(description, { description=it }, label={Text("Description")}, modifier=Modifier.fillMaxWidth()) }
        item { OutlinedTextField(amount, { amount=it.replace(',','.') }, label={Text("Montant (DH)")}, modifier=Modifier.fillMaxWidth()) }
        item {
            Button(
                onClick={ amount.toDoubleOrNull()?.let { onSave(Charge(System.currentTimeMillis(),year,month,type,it,description)) } },
                modifier=Modifier.fillMaxWidth(),
                colors=ButtonDefaults.buttonColors(containerColor=Blue)
            ) { Icon(Icons.Default.Save,null); Spacer(Modifier.width(8.dp)); Text("Enregistrer") }
        }
    }
}

@Composable
fun AddDialog(onDismiss: () -> Unit, onSave: (Charge) -> Unit) {
    AlertDialog(onDismissRequest=onDismiss, confirmButton={}, text={ AddForm(onSave,onDismiss) })
}

@Composable
fun MonthlyScreen(charges: List<Charge>, year: Int, month: Int, onChange: (Int,Int)->Unit) {
    val list = charges.filter { it.year==year && it.month==month }
    val normal = list.filter { it.type=="Normale" }.sumOf { it.amount }
    val ponct = list.filter { it.type=="Ponctuelle" }.sumOf { it.amount }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item { Text("Synthèse mensuelle", fontSize=26.sp, fontWeight=FontWeight.Bold) }
        item { Selector("Année", year.toString()) {} }
        item { Selector("Mois", monthName(month)) {} }
        item { StatCard("Charges normales", normal, Blue) }
        item { StatCard("Charges ponctuelles", ponct, Yellow) }
        item { StatCard("Total du mois", normal+ponct, White) }
        item { Donut(normal, ponct) }
    }
}

@Composable
fun AnnualScreen(charges: List<Charge>, year: Int, onYear: (Int)->Unit) {
    val byMonth = (1..12).map { m -> charges.filter { it.year==year && it.month==m } }
    val normal = byMonth.map { it.filter { c->c.type=="Normale" }.sumOf { it.amount } }
    val ponct = byMonth.map { it.filter { c->c.type=="Ponctuelle" }.sumOf { it.amount } }
    val totalN=normal.sum(); val totalP=ponct.sum()
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item { Text("Vue annuelle", fontSize=26.sp, fontWeight=FontWeight.Bold) }
        item { Selector("Année", year.toString()) {} }
        item { StatCard("Charges normales", totalN, Blue) }
        item { StatCard("Charges ponctuelles", totalP, Yellow) }
        item { StatCard("Total annuel", totalN+totalP, White) }
        item { Donut(totalN,totalP) }
        item { Text("Évolution mensuelle", fontSize=20.sp, fontWeight=FontWeight.Bold) }
        item { BarChart(normal, ponct) }
        items((1..12).toList()) { m ->
            val n=normal[m-1]; val p=ponct[m-1]
            Row(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(12.dp)).padding(12.dp), horizontalArrangement=Arrangement.SpaceBetween) {
                Text(monthName(m)); Text("${money(n)} / ${money(p)} DH", color=White)
            }
        }
    }
}

@Composable
fun BackupScreen(onExport:()->Unit,onImport:()->Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement=Arrangement.spacedBy(16.dp)) {
        Text("Sauvegarde & restauration", fontSize=26.sp, fontWeight=FontWeight.Bold)
        ActionCard("Exporter en JSON","Sauvegarder toutes vos données",Icons.Default.FileDownload,Green,onExport)
        ActionCard("Importer un fichier JSON","Restaurer une sauvegarde",Icons.Default.FileUpload,Color(0xFFB66CFF),onImport)
        Text("⚠ La restauration remplace les données actuelles par celles du fichier sélectionné.", color=Yellow)
    }
}

@Composable fun Selector(label:String,value:String,onClick:()->Unit) {
    OutlinedButton(onClick=onClick,modifier=Modifier.fillMaxWidth()) { Text("$label : $value") }
}
@Composable fun StatCard(title:String,value:Double,color:Color) {
    Card(colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(18.dp),verticalAlignment=Alignment.CenterVertically) {
            Icon(Icons.Default.BarChart,null,tint=color,modifier=Modifier.size(34.dp)); Spacer(Modifier.width(12.dp))
            Column { Text(title,color=Muted); Text("${money(value)} DH",color=if(color==White) White else color,fontSize=24.sp,fontWeight=FontWeight.Bold) }
        }
    }
}
@Composable
fun Donut(a:Double,b:Double) {
    val total=a+b
    Card(colors=CardDefaults.cardColors(containerColor=Card)) {
        Column(Modifier.padding(16.dp),horizontalAlignment=Alignment.CenterHorizontally) {
            Text("Répartition des charges",fontWeight=FontWeight.Bold)
            Canvas(Modifier.size(210.dp)) {
                val stroke=38f
                val sweepA=if(total==0.0)0f else 360f*(a/total)
                drawArc(Blue,-90f,sweepA,false,style=Stroke(stroke,cap=StrokeCap.Butt))
                drawArc(Yellow,-90f+sweepA,360f-sweepA,false,style=Stroke(stroke,cap=StrokeCap.Butt))
            }
            Row(horizontalArrangement=Arrangement.spacedBy(18.dp)) {
                Text("● Normales ${money(a)} DH",color=Blue)
                Text("● Ponctuelles ${money(b)} DH",color=Yellow)
            }
        }
    }
}
@Composable
fun BarChart(normal:List<Double>,ponct:List<Double>) {
    val max=(normal.zip(ponct).maxOfOrNull { it.first+it.second } ?: 1.0).coerceAtLeast(1.0)
    Canvas(Modifier.fillMaxWidth().height(230.dp).padding(8.dp)) {
        val w=size.width/12f
        normal.forEachIndexed { i,n ->
            val p=ponct[i]
            val x=i*w+w*.25f
            val base=size.height-18f
            val hn=(n/max)*(size.height-35f)
            val hp=(p/max)*(size.height-35f)
            drawRect(Blue,Offset(x,base-hn),Size(w*.45f,hn))
            drawRect(Yellow,Offset(x,base-hn-hp),Size(w*.45f,hp))
        }
    }
}
fun monthName(m:Int)=listOf("","Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre")[m.coerceIn(1,12)]
fun money(v:Double)=NumberFormat.getNumberInstance(Locale.FRANCE).format(v)
