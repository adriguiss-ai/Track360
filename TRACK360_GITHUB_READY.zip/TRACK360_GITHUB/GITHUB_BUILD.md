# Compiler TRACK360 avec GitHub Actions

1. Créez un dépôt GitHub nommé `TRACK360`.
2. Décompressez ce projet et envoyez **le contenu du dossier** dans le dépôt (pas le dossier parent lui-même).
3. Vérifiez que `.github/workflows/build-apk.yml` est présent.
4. Faites un commit/push sur `main` (ou `master`).
5. Ouvrez l'onglet **Actions** sur GitHub.
6. Ouvrez **Build TRACK360 APK**.
7. À la fin du workflow, ouvrez la section **Artifacts**.
8. Téléchargez `TRACK360-debug-apk` : il contient l'APK installable de test.

Le workflow installe Java 17 et Gradle 8.10.2 automatiquement. Vous n'avez donc pas besoin d'installer Android Studio pour compiler avec GitHub Actions.

Pour lancer manuellement un build : Actions > Build TRACK360 APK > Run workflow.
