# TRACK360 — TRACK SMARTER

Application Android de suivi des charges, version Black & Yellow.

## Fonctionnalités
- Charges normales et ponctuelles
- Année + mois
- Montant en DH
- Synthèse mensuelle
- Synthèse annuelle
- Évolution mensuelle en graphique à barres dans la vue annuelle
- Vue de toutes les années
- Graphiques circulaires
- Export JSON
- Import / restauration JSON
- Stockage local sur le téléphone

## Compilation
1. Ouvrir ce dossier dans Android Studio.
2. Laisser Gradle synchroniser les dépendances.
3. Build > Build APK(s).
4. L'APK sera généré dans `app/build/outputs/apk/`.

JDK 17 recommandé.
