# TRACK360 Android — version corrigée

Cette version intègre les demandes de l'application TRACK360 :

- Synthèse annuelle conservée.
- Vue annuelle détaillée par mois supprimée.
- Écran entièrement scrollable.
- Haut des écrans protégé contre la barre système.
- Menu inférieur toujours entièrement visible.
- Logo TRACK360 visible également sur le dernier écran (Sauvegarde et restauration).
- Logo TRACK360 présent dans les en-têtes des écrans.
- Marges horizontales adaptées pour éviter les éléments coupés à gauche ou à droite.
- Ajout de charges fonctionnel.
- Sélection année/mois fonctionnelle.
- Boutons réellement cliquables.
- Export/import JSON fonctionnel.
- Données locales persistantes.
- JDK 17 + Gradle 8.9 pour GitHub Actions.
- Icône TRACK360 pour le raccourci de l'application.

## GitHub Actions

Le dépôt peut contenir le fichier `TRACK360_COMPLETE.zip` (ou un autre ZIP contenant le projet) et le `main.yml` fourni.
Le workflow recherche automatiquement le ZIP à la racine, extrait le projet Android, compile l'APK Debug et publie l'artifact `TRACK360-debug-apk`.


### Export Excel
La version V7 ajoute un export `.xlsx` de toutes les charges stockées avec l'année, le mois, le type, le montant, les totaux mensuels normal/ponctuel et le total mensuel. Le bouton est disponible sur l'écran d'accueil, à côté de « Sauvegarde et restauration ».
