package com.track360.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

private val Navy = Color(0xFF06111B)
private val Card = Color(0xFF0D1F2C)
private val Card2 = Color(0xFF112838)
private val Blue = Color(0xFF168BFF)
private val Cyan = Color(0xFF13D8F2)
private val Red = Color(0xFFFF4B5C)
private val White = Color(0xFFF4F7FA)
private val Muted = Color(0xFF9EAFBD)

data class Charge(val year:Int, val month:Int, val normal:Boolean, val amount:Double, val date:String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Android 15+ uses edge-to-edge. The Compose screens below explicitly
        // protect the status-bar area and keep all content inside the safe width.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        window.isNavigationBarContrastEnforced = false
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        setContent { Track360App() }
    }
}

@Composable
fun Track360App() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("track360", Context.MODE_PRIVATE) }
    var charges by remember { mutableStateOf(loadCharges(prefs)) }
    var screen by remember { mutableStateOf("home") }
    var selectedYear by remember { mutableStateOf(Calendar.getInstance().get(Calendar.YEAR)) }
    var selectedMonth by remember { mutableStateOf(Calendar.getInstance().get(Calendar.MONTH)) }
    var showBackup by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) exportJson(context, uri, charges)
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val imported = importJson(context, uri)
            if (imported != null) {
                charges = imported
                saveCharges(prefs, imported)
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Card, primary = Blue, secondary = Cyan,
        onBackground = White, onSurface = White
    )) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            Scaffold(
                containerColor = Navy,
                bottomBar = {
                    BottomBar(screen) { target -> screen = target }
                }
            ) { pad ->
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(pad)
                ) {
                    when (screen) {
                        "home" -> HomeScreen(
                            onAdd = { screen = "add" },
                            onMonthly = { screen = "monthly" },
                            onAnnual = { screen = "annual" },
                            onAllYears = { screen = "allYears" },
                            onBackup = { screen = "backup" }
                        )
                        "add" -> AddChargeScreen(selectedYear, selectedMonth) { y,m,normal,amount ->
                            val date = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
                            val updated = charges + Charge(y,m,normal,amount,date)
                            charges = updated
                            saveCharges(prefs, updated)
                            selectedYear = y; selectedMonth = m
                            screen = "monthly"
                        }
                        "monthly" -> MonthlyScreen(charges, selectedYear, selectedMonth,
                            onYear = { selectedYear = it },
                            onMonth = { selectedMonth = it },
                            onBack = { screen = "home" })
                        "annual" -> AnnualSummaryScreen(charges, selectedYear,
                            onYear = { selectedYear = it },
                            onBack = { screen = "home" })
                        "allYears" -> AllYearsScreen(charges, onBack = { screen = "home" })
                        "backup" -> BackupScreen(
                            onExport = { exportLauncher.launch("TRACK360_backup.json") },
                            onImport = { importLauncher.launch(arrayOf("application/json", "text/json", "*/*")) },
                            onBack = { screen = "home" }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BottomBar(current: String, onSelect: (String) -> Unit) {
    NavigationBar(
        modifier = Modifier.navigationBarsPadding(),
        containerColor = Color(0xFF071521),
        tonalElevation = 0.dp
    ) {
        listOf(
            "home" to "Accueil",
            "add" to "Saisie",
            "monthly" to "Mensuelle",
            "allYears" to "Toutes"
        ).forEach { (key, label) ->
            NavigationBarItem(
                selected = current == key,
                onClick = { onSelect(key) },
                icon = {
                    Text(
                        when (key) {
                            "home" -> "⌂"
                            "add" -> "+"
                            "monthly" -> "▣"
                            else -> "↗"
                        },
                        fontSize = 25.sp,
                        color = if (current == key) Cyan else Muted
                    )
                },
                label = { Text(label, color = if (current == key) Cyan else Muted, fontSize = 10.sp, maxLines = 1) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Cyan,
                    unselectedIconColor = Muted,
                    indicatorColor = Color(0xFF103A53)
                )
            )
        }
    }
}

@Composable
fun AppHeader(title: String, onBack: (() -> Unit)? = null) {
    Column(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onBack != null) {
                Text(
                    "‹",
                    color = Cyan,
                    fontSize = 38.sp,
                    modifier = Modifier
                        .clickable { onBack() }
                        .padding(end = 8.dp)
                )
            }
            Text(
                title,
                color = White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Icon(
                painter = painterResource(R.drawable.track360_logo),
                contentDescription = "TRACK360",
                tint = Color.Unspecified,
                modifier = Modifier.size(42.dp)
            )
        }
        Divider(color = Cyan.copy(alpha = .55f), thickness = 1.dp)
    }
}

@Composable
fun LogoHeader() {
    Column(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(top = 8.dp, bottom = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            painterResource(R.drawable.track360_logo),
            contentDescription = "TRACK360",
            tint = Color.Unspecified,
            modifier = Modifier.size(96.dp)
        )
        Row(verticalAlignment = Alignment.Bottom) {
            Text("TRACK", color = White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
            Text("360", color = Cyan, fontSize = 36.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
        }
        Text("TRACK SMARTER", color = Muted, fontSize = 12.sp, letterSpacing = 3.sp)
    }
}

@Composable
fun HomeScreen(onAdd:()->Unit,onMonthly:()->Unit,onAnnual:()->Unit,onAllYears:()->Unit,onBackup:()->Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        LogoHeader()
        val cards = listOf(
            Triple("＋","Ajouter une charge","Saisir une nouvelle dépense") to onAdd,
            Triple("▥","Synthèse mensuelle","Voir le détail du mois") to onMonthly,
            Triple("▣","Synthèse annuelle","Vue globale de l'année") to onAnnual,
            Triple("↗","Toutes les années","Comparaison globale") to onAllYears,
            Triple("▤","Sauvegarde et restauration","Exporter / Importer JSON") to onBackup
        )
        cards.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                row.forEach { item ->
                    HomeCard(item.first.first,item.first.second,item.first.third,item.second,Modifier.weight(1f))
                }
                if (row.size==1) Spacer(Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun HomeCard(icon:String,title:String,subtitle:String,onClick:()->Unit,modifier:Modifier) {
    Card(modifier.clickable { onClick() }, colors=CardDefaults.cardColors(containerColor=Card),
        shape=RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(20.dp).heightIn(min=145.dp), verticalArrangement=Arrangement.SpaceBetween) {
            Text(icon,color=if(title.contains("charge")) Blue else Cyan,fontSize=38.sp)
            Text(title,color=White,fontSize=20.sp,fontWeight=FontWeight.Bold)
            Text(subtitle,color=Muted,fontSize=14.sp)
            Text("›",color=Muted,fontSize=30.sp,modifier=Modifier.align(Alignment.End))
        }
    }
}

@Composable
fun AddChargeScreen(defaultYear:Int, defaultMonth:Int, onSave:(Int,Int,Boolean,Double)->Unit) {
    var year by remember { mutableStateOf(defaultYear) }
    var month by remember { mutableStateOf(defaultMonth) }
    var normal by remember { mutableStateOf(true) }
    var amount by remember { mutableStateOf("") }
    val years = (2020..2035).toList()
    val months = listOf("Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppHeader("Ajouter une charge")
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalArrangement=Arrangement.spacedBy(16.dp)) {
            Text("Année", color=White)
            DropdownField(year.toString(), years.map{it.toString()}) { year=it.toInt() }
            Text("Mois", color=White)
            DropdownField(months[month], months) { month=months.indexOf(it) }
            Text("Type de charge", color=White)
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp), modifier=Modifier.fillMaxWidth()) {
                TypeButton("▤  Normale", normal, Blue) { normal=true }
                TypeButton("⚠  Ponctuelle", !normal, Red) { normal=false }
            }
            Text("Montant (DH)", color=White)
            OutlinedTextField(amount,{amount=it},singleLine=true,modifier=Modifier.fillMaxWidth(),
                label={Text("Montant")}, colors=fieldColors())
            Button(
                onClick={ { val v=amount.replace(",",".").toDoubleOrNull(); if(v!=null && v>0) onSave(year,month,normal,v) } },
                modifier=Modifier.fillMaxWidth().height(54.dp),
                colors=ButtonDefaults.buttonColors(containerColor=Blue)
            ) { Text("💾  Enregistrer",fontSize=17.sp) }
        }
    }
}

@Composable
fun TypeButton(text:String,selected:Boolean,color:Color,onClick:()->Unit) {
    Button(onClick=onClick, modifier=Modifier.weight(1f).height(52.dp),
        colors=ButtonDefaults.buttonColors(containerColor=if(selected) color else Card2)) {
        Text(text, fontSize=14.sp)
    }
}

@Composable
fun <T> DropdownField(value:String, options:List<T>, onPick:(T)->Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick={expanded=true}, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                Text(value,color=White); Text("⌄",color=Muted)
            }
        }
        DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) {
            options.forEach { option ->
                DropdownMenuItem(text={Text(option.toString())},onClick={expanded=false;onPick(option)})
            }
        }
    }
}

@Composable
fun MonthlyScreen(charges:List<Charge>, year:Int, month:Int,onYear:(Int)->Unit,onMonth:(Int)->Unit,onBack:()->Unit) {
    val normal = charges.filter{it.year==year && it.month==month && it.normal}.sumOf{it.amount}
    val one = charges.filter{it.year==year && it.month==month && !it.normal}.sumOf{it.amount}
    val total=normal+one
    val months=listOf("Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppHeader("Synthèse mensuelle",onBack)
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f)){ DropdownField(year.toString(),(2020..2035).map{it.toString()}){onYear(it.toInt())} }
                Box(Modifier.weight(1f)){ DropdownField(months[month],months){onMonth(months.indexOf(it))} }
            }
            SummaryCard("▤","Charges normales",normal,Blue)
            SummaryCard("⚠","Charges ponctuelles",one,Red)
            SummaryCard("Σ","Total du mois",total,White)
            ChartCard("Répartition des charges (${months[month]} $year)",normal,one)
            MonthlyBars(charges,year)
        }
    }
}

@Composable
fun SummaryCard(icon:String,title:String,value:Double,color:Color) {
    Card(colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(18.dp),verticalAlignment=Alignment.CenterVertically) {
            Text(icon,color=color,fontSize=32.sp,modifier=Modifier.padding(end=16.dp))
            Column { Text(title,color=color,fontSize=15.sp); Text("${fmt(value)} DH",color=White,fontSize=28.sp,fontWeight=FontWeight.Bold) }
        }
    }
}

@Composable
fun ChartCard(title: String, a: Double, b: Double) {
    Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp)) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 17.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Donut(a, b, Modifier.size(145.dp))
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text("Normales", color = Cyan, fontSize = 13.sp)
                    Text("${fmt(a)} DH", color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text("Ponctuelles", color = Red, fontSize = 13.sp)
                    Text("${fmt(b)} DH", color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

@Composable
fun Donut(a:Double,b:Double,modifier:Modifier) {
    val total=a+b
    Canvas(modifier) {
        if(total<=0) {
            drawCircle(Color.DarkGray, style=Stroke(24f))
        } else {
            val sweepA=(a/total*360f).toFloat()
            drawArc(Cyan,-90f,sweepA,false,style=Stroke(24f,cap=StrokeCap.Butt))
            drawArc(Red,-90f+sweepA,(360f-sweepA),false,style=Stroke(24f,cap=StrokeCap.Butt))
        }
    }
}

@Composable
fun MonthlyBars(charges:List<Charge>,year:Int) {
    val values=(0..11).map{m->charges.filter{it.year==year&&it.month==m}.sumOf{it.amount}}
    Card(colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Text("Évolution mensuelle ($year)",color=White,fontWeight=FontWeight.Bold,fontSize=17.sp)
            Spacer(Modifier.height(15.dp))
            Row(Modifier.fillMaxWidth().height(150.dp),horizontalArrangement=Arrangement.spacedBy(5.dp),verticalAlignment=Alignment.Bottom) {
                val max=(values.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
                values.forEachIndexed{idx,v->
                    Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally) {
                        Box(Modifier.fillMaxWidth().height((110*v/max).dp).clip(RoundedCornerShape(4.dp)).background(Blue))
                        Text(listOf("J","F","M","A","M","J","J","A","S","O","N","D")[idx],color=Muted,fontSize=10.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AnnualSummaryScreen(charges: List<Charge>, year: Int, onYear: (Int) -> Unit, onBack: () -> Unit) {
    val normal = charges.filter { it.year == year && it.normal }.sumOf { it.amount }
    val one = charges.filter { it.year == year && !it.normal }.sumOf { it.amount }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppHeader("Synthèse annuelle", onBack)
        Column(
            Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            DropdownField(year.toString(), (2020..2035).map { it.toString() }) { onYear(it.toInt()) }
            SummaryCard("▤", "Charges normales", normal, Blue)
            SummaryCard("⚠", "Charges ponctuelles", one, Red)
            SummaryCard("Σ", "Total de l'année", normal + one, White)
            ChartCard("Répartition annuelle ($year)", normal, one)
            Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("Synthèse $year", color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "La vue annuelle par mois a été supprimée. Utilisez la synthèse mensuelle pour consulter un mois précis.",
                        color = Muted,
                        fontSize = 14.sp
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
fun AllYearsScreen(charges:List<Charge>,onBack:()->Unit) {
    val years=charges.map{it.year}.distinct().sortedDescending().ifEmpty{listOf(Calendar.getInstance().get(Calendar.YEAR))}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppHeader("Toutes les années",onBack)
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            years.forEach{y->
                val t=charges.filter{it.year==y}.sumOf{it.amount}
                Card(colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(16.dp)) {
                    Row(Modifier.fillMaxWidth().padding(18.dp),horizontalArrangement=Arrangement.SpaceBetween) {
                        Text(y.toString(),color=Cyan,fontSize=20.sp,fontWeight=FontWeight.Bold)
                        Text("${fmt(t)} DH",color=White,fontSize=20.sp,fontWeight=FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun BackupScreen(onExport:()->Unit,onImport:()->Unit,onBack:()->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppHeader("Sauvegarde et restauration", onBack)
        Column(
            Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    painterResource(R.drawable.track360_logo),
                    contentDescription = "TRACK360",
                    tint = Color.Unspecified,
                    modifier = Modifier.size(92.dp)
                )
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("TRACK", color = White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text("360", color = Cyan, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 6.dp))
                }
                Text("TRACK SMARTER", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
            }
            Card(colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                    Icon(painterResource(R.drawable.track360_logo),null,tint=Color.Unspecified,modifier=Modifier.size(120.dp))
                    Text("Sauvegarde des données",color=White,fontSize=20.sp,fontWeight=FontWeight.Bold)
                    Text("Exportez toutes vos charges au format JSON.",color=Muted,textAlign=TextAlign.Center)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick=onExport,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Blue)){Text("⬇  Exporter en JSON")}
                }
            }
            Card(colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                    Icon(painterResource(R.drawable.track360_logo),null,tint=Color.Unspecified,modifier=Modifier.size(90.dp))
                    Text("Restauration des données",color=White,fontSize=20.sp,fontWeight=FontWeight.Bold)
                    Text("Importez un fichier JSON pour restaurer vos charges.",color=Muted,textAlign=TextAlign.Center)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick=onImport,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF7047E8))){Text("⬆  Importer un fichier JSON")}
                }
            }
            Text("⚠ La restauration remplace les données actuelles par celles du fichier sélectionné.",color=Color(0xFFFFB000))
            Text("Format JSON local : vos données restent sur l'appareil jusqu'à exportation.",color=Muted)
        }
    }
}

@Composable
fun fieldColors()=OutlinedTextFieldDefaults.colors(
    focusedBorderColor=Cyan,unfocusedBorderColor=Muted,
    focusedLabelColor=Cyan,unfocusedLabelColor=Muted,
    focusedTextColor=White,unfocusedTextColor=White,
    cursorColor=Cyan
)

fun fmt(v:Double):String = if(v % 1.0 == 0.0) String.format(Locale.US,"%.0f",v) else String.format(Locale.US,"%.2f",v)

fun loadCharges(prefs:android.content.SharedPreferences):List<Charge> {
    return try {
        val arr=JSONArray(prefs.getString("charges","[]"))
        List(arr.length()){i->
            val o=arr.getJSONObject(i)
            Charge(o.getInt("year"),o.getInt("month"),o.getBoolean("normal"),o.getDouble("amount"),o.getString("date"))
        }
    } catch(_:Exception){ emptyList() }
}

fun saveCharges(prefs:android.content.SharedPreferences,charges:List<Charge>) {
    val arr=JSONArray()
    charges.forEach{c->
        arr.put(JSONObject().apply {
            put("year",c.year);put("month",c.month);put("normal",c.normal);put("amount",c.amount);put("date",c.date)
        })
    }
    prefs.edit().putString("charges",arr.toString()).apply()
}

fun exportJson(context:Context,uri:Uri,charges:List<Charge>) {
    val root=JSONObject().put("app","TRACK360").put("version",1).put("charges",JSONArray().apply{
        charges.forEach{c->put(JSONObject().apply{
            put("year",c.year);put("month",c.month);put("normal",c.normal);put("amount",c.amount);put("date",c.date)
        })}
    })
    context.contentResolver.openOutputStream(uri)?.use{it.write(root.toString(2).toByteArray())}
}

fun importJson(context:Context,uri:Uri):List<Charge>? {
    return try {
        val text=context.contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()} ?: return null
        val arr=JSONObject(text).getJSONArray("charges")
        List(arr.length()){i->
            val o=arr.getJSONObject(i)
            Charge(o.getInt("year"),o.getInt("month"),o.getBoolean("normal"),o.getDouble("amount"),o.optString("date",""))
        }
    } catch(_:Exception){ null }
}
